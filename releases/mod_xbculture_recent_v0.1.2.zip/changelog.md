v0.9.4.1 : 29th April 2021 - minor bug fixes 
 - removed debug message in new film
 - corrected missing language strings in menu xml's

v0.9.4 : 17th April 2021 - first JED release
 - major reworking of elements common to all xbCulture components
 - common stylesheet now installed as part of xbPeople component
 - common language strings file now installed as part of xbPeople component
 - xbFilms will no longer work without xbPeople being installed - use the package install file, or install xbPeople before installing xbFilms
