<?php
/*******
 * @package xbCulture
 * @filesource mod_xbculture_recent/mod_xbculture_recent.php
 * @version 0.1.0 26th April 2021
 * @author Roger C-O
 * @copyright Copyright (c) Roger Creagh-Osborne, 2021
 * @license GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 ******/
//no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

use Joomla\CMS\Factory;

require_once( dirname(__FILE__).'/helper.php' );

$items = modXbcultureRecentHelper::getitems( $params );

$document	= Factory::getDocument();
$document->addStyleSheet(JURI::base(true).'/media/com_xbpeople/css/xb.css');
require( JModuleHelper::getLayoutPath( 'mod_xbculture_recent' ));

?>
