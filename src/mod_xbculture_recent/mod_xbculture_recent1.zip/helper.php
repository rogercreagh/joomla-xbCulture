<?php
/*******
 * @package xbCulture
 * @filesource mod_xbculture_recent/helper.php
 * @version 0.1.0 26th April 2021
 * @author Roger C-O
 * @copyright Copyright (c) Roger Creagh-Osborne, 2021
 * @license GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 ******/
defined('_JEXEC') or die('Restricted access');

use Joomla\CMS\Factory;

class modXbcultureRecentHelper {
	
	static function getItems($params) {
		$cnt = $params->get('itemcnt');
		$db = Factory::getDbo();
		$query = $db->getQuery(true);
		$query->select($db->quoteName('title'))
			->from('#__xbfilms')
			->order('date_seen DESC');
		$db->setQuery($query,0,$cnt);
		$items = $db->loadObjectList();
		return $items;
	}
		
}

?>
