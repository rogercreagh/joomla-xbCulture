<?php
/*******
 * @package xbCulture
 * @filesource mod_xbculture_list/helper.php
 * @version 0.1.0 1st May 2021
 * @author Roger C-O
 * @copyright Copyright (c) Roger Creagh-Osborne, 2021
 * @license GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 ******/
defined('_JEXEC') or die('Restricted access');

use Joomla\CMS\Factory;

class modXbcultureListHelper {
	
	static function getItems($params) {
		$cnt = $params->get('itemcnt');
		$comp = $params->get('comp');
//		$usebooks = Factory::getSession()->get('xbbooks_ok',false) && $params->get('usebooks');
//		$usefilms = Factory::getSession()->get('xbbooks_ok',false) && $params->get('usefilms');
		$filt = $params->get('filter');
		$display = $params->get('display');
		$sortby = $params->get('sortby');
		$sortdir = $params->get('sortdir');
		$reviewed = $params->get('reviewed');
		$filter = $params->get('filter');
		switch ($sortby) {
			case 'dat':
				$order = (($reviewed==1) ||($filter=='rating')) ? 'rev_date' : 'cat_date';
				break;
			case 'rat':
				$order = 'r.rating';	
				break;				
			default:
				$order = 'a.title';
				break;
		}
		switch ($comp) {
			case 'xbbooks':
				$img = 'cover_img';
				$itemid = 'book_id';
				$tablea = '#__xbbooks';
				$tabler = '#__xbbookreviews';
				$catfilt = $params->get('bcatfilt');
				break;
			case 'xbfilms':
				$img = 'poster_img';
				$itemid = 'film_id';
				$tablea = '#__xbfilms';
				$tabler = '#__xbfilmreviews';
				$catfilt = $params->get('fcatfilt');
				break;				
			default:
				
			break;
		}
		
		$db = Factory::getDbo();
		$items = array();
		$query = $db->getQuery(true);
		$query->select('a.id AS id, a.cat_date, a.title, b.'.$img.' AS image')
		->from($tablea.' AS a');
		if (($sortby == 'rat') || ($reviewed==1) || ($filter == 'rating')){
			$query->select('r.rev_date, r.rating');
			$query->join('INNER',$tableb.' AS r ON '.$itemid.' = a.id');
		}
		switch ($filter) {
			case 'cat':
				$query->where('a.catid = '.$db->quote($params->get($catfilt)));
			case 'tag':
				$query->where();
			case 'rating':
				$query->where('r.rating = '.$db->quote($params->get($ratfilt)));
			case 'person':
				$query->where();
			break;
			
			default:
				
			break;
		}		
		
		$query->order($order.' '.$sortdir);
		if ($order != 'title') {
			$query->order($order.' ASC');
		}
		if ($sortby=='dat') {
			$db->setQuery($query,0,$cnt);
		} else {
			$db->setQuery($query); //e may get more than we want so we'll randomly pick some after 
		}
			
		$items = $db->loadObjectList();
		
		//if number returned more than $cnt pick random items from the list
		if ($count($items)>$cnt) {
			$randkeys = array_rand($items,$cnt);
			$items = array_intersect_assoc($items, $randkeys);
		}
		return $items;		
	}
		
	static function dateSort( $a, $b ) {
		return $a->odate == $b->odate ? 0 : (( $a->odate > $b->odate ) ? -1 : 1);
	}
}

?>
